
exports.handler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');
    const gross = Number(body.gross || 0);
    const discount = Number(body.discount || 0);
    const vat = Number(body.vat || 0.25);
    const price = gross * (1 - discount) * (1 + vat);
    return { statusCode: 200, body: JSON.stringify({ price }) };
  } catch (error) {
    return { statusCode: 500, body: JSON.stringify({ error: error.message }) };
  }
};
