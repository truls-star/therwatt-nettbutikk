
exports.handler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');
    const items = Array.isArray(body.items) ? body.items : [];
    if (!items.length) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Ingen varer i handlekurven.' }) };
    }

    if (!process.env.STRIPE_SECRET_KEY) {
      return { statusCode: 200, body: JSON.stringify({ url: '/ordre-sendt.html' }) };
    }

    const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
    const origin = process.env.URL || process.env.DEPLOY_PRIME_URL || '';

    const line_items = items.map(item => ({
      price_data: {
        currency: 'nok',
        product_data: { name: item.name },
        unit_amount: Math.round(Number(item.price || 0) * 100)
      },
      quantity: Number(item.qty || 1)
    }));

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items,
      success_url: `${origin}/ordre-sendt.html`,
      cancel_url: `${origin}/butikk.html`
    });

    return { statusCode: 200, body: JSON.stringify({ url: session.url }) };
  } catch (error) {
    return { statusCode: 500, body: JSON.stringify({ error: error.message }) };
  }
};
